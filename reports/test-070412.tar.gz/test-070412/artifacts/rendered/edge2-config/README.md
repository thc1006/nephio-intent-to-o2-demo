# Edge2 GitOps Configuration

This directory contains the GitOps configuration for the Edge2 O-Cloud cluster deployed on VM-4.

## Directory Structure

```
edge2-config/
├── sync-config.yaml          # Config Sync RootSync configuration
├── kustomization.yaml        # Root Kustomization
├── namespaces.yaml          # Namespace definitions
├── network-functions/       # O-RAN network function deployments
│   └── kustomization.yaml
├── services/                # Core services and load balancers
│   ├── kustomization.yaml
│   ├── service-discovery.yaml
│   ├── load-balancer.yaml
│   └── ingress-config.yaml
└── monitoring/              # Observability stack
    ├── kustomization.yaml
    ├── prometheus-config.yaml
    ├── grafana-config.yaml
    ├── alerting-rules.yaml
    ├── slo-monitoring.yaml
    └── dashboards.json
```

## Cluster Information

- **Cluster Name**: edge2
- **VM**: VM-4 (172.16.0.89)
- **API Server**: https://172.16.0.89:6443
- **Context**: kind-edge2
- **GitOps Repo**: http://172.16.0.78:30000/admin1/edge2-config

## Service Endpoints

### NodePort Services
- **HTTP Ingress**: 172.16.0.89:31080
- **HTTPS Ingress**: 172.16.0.89:31443
- **O2IMS API**: 172.16.0.89:31280
- **Grafana UI**: 172.16.0.89:31300

### Internal Services
- **Prometheus**: prometheus.monitoring:9090
- **SLO Gateway**: slo-gateway.monitoring:8081
- **Service Discovery**: service-discovery.oran-services:8500

## Namespaces

1. **oran-nfs**: O-RAN network functions
2. **oran-services**: Core O-RAN services
3. **monitoring**: Prometheus, Grafana, and SLO monitoring

## Config Sync Setup

The cluster uses Config Sync to automatically synchronize configurations from this Git repository.

### Apply RootSync Configuration

```bash
kubectl apply -f sync-config.yaml
```

### Verify Sync Status

```bash
# Check RootSync status
kubectl -n config-management-system get rootsync edge2-rootsync -o yaml

# Check reconciler logs
kubectl -n config-management-system logs -l app=root-reconciler --tail=50

# Check git-sync logs
kubectl -n config-management-system logs -l app=git-sync --tail=50
```

## Deployment Commands

### Manual Apply (for testing)

```bash
# Apply all configurations
kubectl apply -k .

# Apply specific component
kubectl apply -k services/
kubectl apply -k monitoring/
```

### Rollback

```bash
# Revert to previous Git commit
git revert HEAD
git push

# Config Sync will automatically apply the rollback
```

## Monitoring and Observability

### Access Grafana

```bash
# Port-forward for local access
kubectl port-forward -n monitoring svc/grafana 3000:3000

# Or access via NodePort
curl http://172.16.0.89:31300
```

### Query Prometheus

```bash
# Port-forward for local access
kubectl port-forward -n monitoring svc/prometheus 9090:9090

# Query metrics
curl http://localhost:9090/api/v1/query?query=up
```

### Check SLO Status

```bash
# Get SLO metrics
curl http://172.16.0.89:31280/metrics/api/v1/slo
```

## Multi-Site Considerations

Edge2 is part of a multi-site deployment:
- **Edge1** (VM-2): Primary edge site
- **Edge2** (VM-4): Secondary edge site
- **SMO** (VM-1): Service Management Orchestrator

Intent-based deployments target specific sites via the `targetSite` field:
- `targetSite: edge1` - Deploy to Edge1 only
- `targetSite: edge2` - Deploy to Edge2 only
- `targetSite: both` - Deploy to both sites

## Troubleshooting

### Config Sync Not Working

1. Check network connectivity to Gitea:
```bash
kubectl run debug --rm -it --image=alpine/git -- \
  git ls-remote http://172.16.0.78:30000/admin1/edge2-config
```

2. Verify secret:
```bash
kubectl get secret gitea-token -n config-management-system -o yaml
```

3. Check reconciler status:
```bash
kubectl -n config-management-system describe rootsync edge2-rootsync
```

### Services Not Accessible

1. Check service status:
```bash
kubectl get svc -A | grep NodePort
```

2. Verify ingress controller:
```bash
kubectl get pods -n oran-services | grep nginx
```

3. Test connectivity:
```bash
curl -v http://172.16.0.89:31080/health
```

## Security Considerations

- Git credentials are stored as Kubernetes secrets
- Network policies restrict egress to necessary endpoints
- RBAC limits Config Sync permissions to required namespaces
- All inter-service communication uses TLS where applicable

## Contact

- **Platform Team**: DevOps
- **Repository**: http://172.16.0.78:30000/admin1/edge2-config
- **Issues**: Create in Gitea or contact platform team